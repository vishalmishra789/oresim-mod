/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.class_1923
 *  net.minecraft.class_2246
 *  net.minecraft.class_2248
 *  net.minecraft.class_2338
 *  net.minecraft.class_2561
 *  net.minecraft.class_2818
 *  net.minecraft.class_310
 */
package com.oresp;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2818;
import net.minecraft.class_310;

@Environment(value=EnvType.CLIENT)
public class OreEspState {
    private static final OreEspState INSTANCE = new OreEspState();
    private boolean active = false;
    private final List<class_2338> orePositions = new ArrayList<class_2338>();
    private static final int CHUNK_RADIUS = 4;
    public static final Set<class_2248> TARGET_ORES = Set.of((Object)class_2246.field_10442, (Object)class_2246.field_29029, (Object)class_2246.field_10212, (Object)class_2246.field_29027, (Object)class_2246.field_10571, (Object)class_2246.field_29026, (Object)class_2246.field_23077, (Object)class_2246.field_22109);

    public static OreEspState getInstance() {
        return INSTANCE;
    }

    private OreEspState() {
    }

    public boolean isActive() {
        return this.active;
    }

    public List<class_2338> getOrePositions() {
        return this.orePositions;
    }

    public void activate(String seedArg) {
        this.active = true;
        this.scan();
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            client.field_1724.method_7353((class_2561)class_2561.method_43470((String)("\u00a7a[OreESP] \u00a7fEnabled \u2014 seed \u00a7e" + seedArg + "\u00a7f. Found \u00a7b" + this.orePositions.size() + "\u00a7f ore blocks nearby.")), false);
        }
    }

    public void deactivate() {
        this.active = false;
        this.orePositions.clear();
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            client.field_1724.method_7353((class_2561)class_2561.method_43470((String)"\u00a7c[OreESP] \u00a7fDisabled."), false);
        }
    }

    public void scan() {
        this.orePositions.clear();
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null || client.field_1724 == null) {
            return;
        }
        class_2338 playerPos = client.field_1724.method_24515();
        int centerCX = playerPos.method_10263() >> 4;
        int centerCZ = playerPos.method_10260() >> 4;
        int minY = client.field_1687.method_31607();
        int maxY = client.field_1687.method_31607() + client.field_1687.method_31605();
        for (int cx = centerCX - 4; cx <= centerCX + 4; ++cx) {
            for (int cz = centerCZ - 4; cz <= centerCZ + 4; ++cz) {
                class_2818 chunk = client.field_1687.method_2935().method_21730(cx, cz);
                if (chunk == null) continue;
                class_1923 cp = chunk.method_12004();
                int startX = cp.method_8326();
                int startZ = cp.method_8328();
                for (int x = startX; x < startX + 16; ++x) {
                    for (int z = startZ; z < startZ + 16; ++z) {
                        for (int y = minY; y < maxY; ++y) {
                            class_2338 pos = new class_2338(x, y, z);
                            class_2248 block = client.field_1687.method_8320(pos).method_26204();
                            if (!TARGET_ORES.contains(block)) continue;
                            this.orePositions.add(pos.method_10062());
                        }
                    }
                }
            }
        }
    }
}

