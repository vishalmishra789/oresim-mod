package com.oresp.render;

import com.mojang.blaze3d.systems.RenderSystem;
import com.oresp.OreEspState;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.*;

import java.util.List;

@Environment(EnvType.CLIENT)
public class EspRenderer {

    private static final float EXPAND = 0.003F;

    // 🔥 Optimization limits
    private static final int MAX_CHUNK_RADIUS = 3;
    private static final double MAX_DISTANCE_SQ = 80 * 80; // reduced for performance

    public static void onAfterTranslucent(WorldRenderContext context) {

        OreEspState state = OreEspState.getInstance();
        if (!state.isActive()) return;

        List<class_2338> positions = state.getOrePositions();
        if (positions == null || positions.isEmpty()) return;

        class_4587 matrices = context.matrixStack();
        class_4597 provider = context.consumers();
        if (matrices == null || provider == null) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || mc.field_1724 == null) return;

        class_243 camPos = context.camera().method_19326();
        class_4597.class_4598 consumers = (class_4597.class_4598) provider;

        // 🔥 Player chunk (cached once)
        int playerChunkX = mc.field_1724.method_24515().method_10263() >> 4;
        int playerChunkZ = mc.field_1724.method_24515().method_10260() >> 4;

        // 🔥 Render setup (TRUE XRAY)
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false); // 🔥 KEY FOR XRAY
        RenderSystem.disableCull();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.lineWidth(1.5F);

        class_4588 buffer = consumers.getBuffer(class_1921.field_21695);

        int rendered = 0; // 🔥 limit draw count

        for (class_2338 pos : positions) {

            // 🔥 HARD LIMIT (prevents lag spikes)
            if (rendered > 800) break;

            int px = pos.method_10263();
            int py = pos.method_10264();
            int pz = pos.method_10260();

            // ✅ Chunk culling
            int chunkX = px >> 4;
            int chunkZ = pz >> 4;

            if (Math.abs(chunkX - playerChunkX) > MAX_CHUNK_RADIUS ||
                Math.abs(chunkZ - playerChunkZ) > MAX_CHUNK_RADIUS) continue;

            // ✅ Distance culling (fast squared distance)
            double dxp = mc.field_1724.method_23317() - px;
            double dyp = mc.field_1724.method_23318() - py;
            double dzp = mc.field_1724.method_23321() - pz;

            if ((dxp * dxp + dyp * dyp + dzp * dzp) > MAX_DISTANCE_SQ) continue;

            // ✅ Block check (skip air instantly)
            class_2248 block = mc.field_1687.method_8320(pos).method_26204();
            if (block == class_2246.field_10124) continue; // air

            float[] c = getColor(block);

            // 🔥 Camera relative (faster reuse)
            double dx = px - camPos.field_1352;
            double dy = py - camPos.field_1351;
            double dz = pz - camPos.field_1350;

            float x1 = (float) (dx - EXPAND);
            float y1 = (float) (dy - EXPAND);
            float z1 = (float) (dz - EXPAND);

            float x2 = (float) (dx + 1 + EXPAND);
            float y2 = (float) (dy + 1 + EXPAND);
            float z2 = (float) (dz + 1 + EXPAND);

            drawBox(buffer, matrices, x1, y1, z1, x2, y2, z2, c[0], c[1], c[2], 1.0F);

            rendered++;
        }

        consumers.method_22994(class_1921.field_21695);

        // 🔥 restore properly (IMPORTANT)
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        RenderSystem.lineWidth(1.0F);
    }

    // ⚡ ultra-fast color resolver (no world lookup)
    private static float[] getColor(class_2248 block) {

        if (block == class_2246.field_10442 || block == class_2246.field_29029)
            return new float[]{0.0F, 0.9F, 1.0F}; // diamond

        if (block == class_2246.field_10212 || block == class_2246.field_29027)
            return new float[]{0.9F, 0.6F, 0.4F}; // copper

        if (block == class_2246.field_10571 ||
            block == class_2246.field_29026 ||
            block == class_2246.field_23077)
            return new float[]{1.0F, 0.85F, 0.0F}; // gold

        if (block == class_2246.field_22109)
            return new float[]{0.8F, 0.1F, 0.1F}; // redstone

        return new float[]{1.0F, 1.0F, 1.0F};
    }

    private static void drawBox(class_4588 c, class_4587 m,
                                float x1, float y1, float z1,
                                float x2, float y2, float z2,
                                float r, float g, float b, float a) {

        class_4587.class_4665 e = m.method_23760();

        edge(c, e, x1,y1,z1, x2,y1,z1, r,g,b,a);
        edge(c, e, x2,y1,z1, x2,y1,z2, r,g,b,a);
        edge(c, e, x2,y1,z2, x1,y1,z2, r,g,b,a);
        edge(c, e, x1,y1,z2, x1,y1,z1, r,g,b,a);

        edge(c, e, x1,y2,z1, x2,y2,z1, r,g,b,a);
        edge(c, e, x2,y2,z1, x2,y2,z2, r,g,b,a);
        edge(c, e, x2,y2,z2, x1,y2,z2, r,g,b,a);
        edge(c, e, x1,y2,z2, x1,y2,z1, r,g,b,a);

        edge(c, e, x1,y1,z1, x1,y2,z1, r,g,b,a);
        edge(c, e, x2,y1,z1, x2,y2,z1, r,g,b,a);
        edge(c, e, x2,y1,z2, x2,y2,z2, r,g,b,a);
        edge(c, e, x1,y1,z2, x1,y2,z2, r,g,b,a);
    }

    private static void edge(class_4588 c, class_4587.class_4665 e,
                             float x1,float y1,float z1,
                             float x2,float y2,float z2,
                             float r,float g,float b,float a) {

        float dx = x2 - x1;
        float dy = y2 - y1;
        float dz = z2 - z1;

        float len = (float)Math.sqrt(dx*dx + dy*dy + dz*dz);
        if (len == 0) return;

        dx /= len;
        dy /= len;
        dz /= len;

        int ri = (int)(r * 255);
        int gi = (int)(g * 255);
        int bi = (int)(b * 255);
        int ai = (int)(a * 255);

        c.method_56824(e, x1,y1,z1).method_1336(ri,gi,bi,ai).method_60831(e, dx,dy,dz);
        c.method_56824(e, x2,y2,z2).method_1336(ri,gi,bi,ai).method_60831(e,-dx,-dy,-dz);
    }
}