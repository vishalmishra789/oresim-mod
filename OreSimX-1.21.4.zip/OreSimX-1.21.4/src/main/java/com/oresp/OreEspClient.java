/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.api.ClientModInitializer
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents
 *  net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents
 */
package com.oresp;

import com.oresp.OreEspState;
import com.oresp.render.EspRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;

@Environment(value=EnvType.CLIENT)
public class OreEspClient
implements ClientModInitializer {
    public void onInitializeClient() {
        ClientSendMessageEvents.ALLOW_CHAT.register(message -> {
            String arg;
            if (message == null || !message.trim().startsWith(".seed")) {
                return true;
            }
            String[] parts = message.trim().split("\\s+", 2);
            String string = arg = parts.length > 1 ? parts[1].trim() : "";
            if (arg.isEmpty() || arg.equalsIgnoreCase("off")) {
                OreEspState.getInstance().deactivate();
            } else {
                OreEspState.getInstance().activate(arg);
            }
            return false;
        });
        int[] frameCounter = new int[]{0};
        WorldRenderEvents.AFTER_TRANSLUCENT.register(context -> {
            OreEspState state = OreEspState.getInstance();
            if (!state.isActive()) {
                return;
            }
            frameCounter[0] = frameCounter[0] + 1;
            if (frameCounter[0] >= 40) {
                frameCounter[0] = 0;
                state.scan();
            }
            EspRenderer.onAfterTranslucent(context);
        });
    }
}

